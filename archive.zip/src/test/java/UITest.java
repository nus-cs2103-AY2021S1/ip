import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;


public class UITest {
    @Test
    public void MessagePrintTest(){
            String testString = "☹ OOPS!!! The description of a Deadline cannot be empty.";
            UI ui = new UI();
    }
}
