public class InvalidInputException extends DukeException {
    public InvalidInputException() {
        super("☹ OOPS!!! Sorry I do not understand this command!");
    }
}
