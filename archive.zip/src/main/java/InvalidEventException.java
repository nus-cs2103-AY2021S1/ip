public class InvalidEventException extends DukeException {
    public InvalidEventException() {
        super("☹ OOPS!!! The description of a Event cannot be empty.");
    }
}
