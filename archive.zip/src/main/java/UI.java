public class UI {

    public void showLoadingError(DukeException e){
        System.out.println(e);
    }
}
