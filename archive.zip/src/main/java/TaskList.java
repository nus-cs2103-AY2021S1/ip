import java.util.ArrayList;

public class TaskList {
    ArrayList<Task> listOfItems;
    public TaskList(ArrayList<Task> listOfItems) {
        this.listOfItems = listOfItems;
    }

}
